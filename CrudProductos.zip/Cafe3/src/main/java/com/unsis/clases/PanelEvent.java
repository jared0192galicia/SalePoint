package com.unsis.clases;

/**
 *
 * @author RAVEN
 */
public interface PanelEvent {

    public void selected(int index, int subIndex);
}
